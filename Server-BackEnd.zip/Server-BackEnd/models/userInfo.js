const Sequelize = require("sequelize");

const sequelize = require("../util/database");

const FarmerInfo = sequelize.define(
  "farmerinfo",
  {
    FarmerID: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      allowNull: false,
      primaryKey: true,
    },
    UserID: {
      type: Sequelize.INTEGER,
      allowNull: false,
    },
    CropDetailID: {
      type: Sequelize.INTEGER,
      allowNull: true,
    },
    RSBSA: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
    Fullname: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
    Address: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
    ProfileImg: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
  },
  {
    tableName: "farmerinfo",
    timestamps: false,
  }
);

const TraderInfo = sequelize.define(
  "traderinfo",
  {
    FarmerID: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      allowNull: false,
      primaryKey: true,
    },
    UserID: {
      type: Sequelize.INTEGER,
      allowNull: false,
    },
    PurchasingDetailID: {
      type: Sequelize.INTEGER,
      allowNull: true,
    },
    TraderType: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
    Fullname: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
    Address: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
    ProfileImg: {
      type: Sequelize.STRING(255),
      allowNull: true,
    },
  },
  {
    tableName: "traderinfo",
    timestamps: false,
  }
);

module.exports = { FarmerInfo: FarmerInfo, TraderInfo: TraderInfo };
